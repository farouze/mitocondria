# IEEE manuscript / Overleaf project (revision 2, 2026-09-24)

Upload this ZIP to Overleaf (New Project > Upload Project), set main.tex as the main document, and compile with pdfLaTeX. Compiled locally with pdfLaTeX + BibTeX (9 pages, no unresolved references). manuscript_preview.pdf is included.

## Changes in this revision
- Original title kept at the author's request ("Toward Homeostatic Invariance in Mitochondrial Systems: Representation Bias and Measurement Reliability in 3D Morphometry"); the abstract's last sentence and the keywords tie it to the framework. The imaging analysis is now the supplementary negative result S1 (Appendix), and the experiments are renumbered E1-E7.
- Added the label-pipeline mechanism (mesh-fusion 256^3, 1.5-voxel depth offset; expected 0.00326, measured 0.00304), the pure-outward-shift finding, the note that the data article says 10,000 points where the files have 100,000, and the replication of the offset in the second batch.
- Reframed coverage: 95.1% (nominal) outside the pre-existing low-occupancy QC flag.
- Added Bland-Altman results for E1 (bias, limits of agreement, percentage error, proportional bias), the ICC(A,1) form, the repeatability formula, the source of the 2.17% margin, the query box, the point-cloud flag definition, 3DMSL biological provenance, and the link between the 24 nm grid and 3DMSL.
- Added 13 references (Occupancy Networks, mesh-fusion, marching cubes, winding numbers, McGraw & Wong, Critchley, Efron, weighted/conditional conformal, Lindblad, MiNA, MitoGraph, Nellie). Fixed ref8, ref15, ref20 and Parlakgül.
- Removed the redundant accuracy and coverage bar charts. Table V is now single-column, and the frozen-error figure is single-column (about 250 dpi).
- Added the author affiliation, data/code availability and ethics statements, and cut drafting notes and inline hedges.

## Section 22 results applied (2026-09-25)
- Table IV: equal coverage for the uncorrected and global methods confirmed. They cover identical sets of objects (530/550 internal, 2,456/2,728 frozen), and the arithmetic reason is explained in the text.
- E5: refit with exact distances and convergence screening. 57/60 fits were accepted; median t50 0.00304 (IQR 0.00287-0.00315), t_vol 0.00312, ratio 0.98, r 0.58. The 32-centroid approximation equalled the exact distance for every point. The E5 limitation sentence was replaced.
- Fig. 1: main.tex now uses `figures/frozen_errors` with no extension. Copy `frozen_errors.pdf` from `HIT_outputs_verified/paper_fixes/20260925T143843Z/frozen_figure_and_coverage/` into `figures/`; until then the old PNG is used.

## Revision 5 (2026-09-25)
- Abstract trimmed to 244 words. Table IV is now single-column. Slope units and the meaning of "1,203 IDs" are clarified.
- Fig. 1 redrawn from the refit (Section 23 run: median t50 0.00304, r 0.577, 57 accepted fits, 168,442 pooled points); 300-dpi PNG included. You can optionally replace it with `mechanism_offset.pdf` from Drive.
- Still to confirm: the repeatability rescaling (fold SD / sqrt(10)) in the Methods matches `repeatability.py`.

## Revision 7 (2026-09-26): Section 24 results
- E8, the controlled label-pipeline test, is added: Methods section, Results section, new Fig. 4 (dose-response) and a row in Table III. The earlier "0.93x half-ray" argument is replaced by the direct test.
- Appendix S2 (exploratory model sensitivity, Table VIII) is added. The Data availability section notes the exact reproduction (difference < 5e-14).
- The abstract is 250 words and the paper is 10 pages.

## Revision 8 (2026-09-26): external audit of Section 24 addressed
- E8 primary analysis now uses the 55 non-pilot objects; all 60 are the sensitivity analysis. Both label conventions are reported, t50 uses accepted pairs only, and the decision history and the trilinear-labeling approximation are disclosed. Numbers come from `recreation_reanalysis.json`.
- Pending from Section 25: the ridge row rerun with fold-specific scaling, and one sentence quantifying mesh-containment vs trilinear labels.

## Author checks (marked "AUTHOR CHECK" in main.tex)
- Acknowledgment/funding (and e-mails/corresponding author if the venue requires them). Affiliations confirmed.
- MitoEM exclusion counts per eligibility criterion.
- Code repository URL/DOI (currently "on reasonable request").
