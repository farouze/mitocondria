from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
colors=['#28648a','#bd632d']
data={'accuracy':{'methods':['Uncorrected','Global','Occupancy-only'],'internal_mdape':[3.035,1.370,.580],'frozen_mdape':[3.481,1.503,.664],'internal_rmse':[4.286,2.231,1.149],'frozen_rmse':[5.743,3.542,1.743]},'coverage':{'groups':['All objects','Low occupancy','Higher occupancy'],'internal':[96.2,43.8,97.8],'frozen':[92.1,49.2,95.1],'internal_n':[550,16,534],'frozen_n':[2728,181,2547]},'resolution':{'in_plane_nm':[16,24],'volume':[[.98,.45,1.46],[-.08,-.93,.41]],'surface_area':[[-5.84,-7.68,-4.72],[-10.60,-12.14,-8.67]],'sphericity':[[6.90,5.68,8.69],[11.76,9.24,13.75]]}}
(root/'data/reported_summary_values.json').write_text(json.dumps(data,indent=2))
def save(fig,name):
 fig.savefig(root/f'figures/{name}.pdf',bbox_inches='tight')
 fig.savefig(root/f'figures/{name}.png',dpi=300,bbox_inches='tight');plt.close(fig)
# Only the resolution figure is generated; the accuracy and coverage bar charts were removed because Tables IV and V report the same values.
fig,axs=plt.subplots(1,3,figsize=(7.1,2.55),layout='constrained')
for ax,key,label in zip(axs,['volume','surface_area','sphericity'],['(a) Volume','(b) Surface area','(c) Sphericity']):
 arr=np.array(data['resolution'][key]); med=arr[:,0]
 ax.errorbar([16,24],med,yerr=np.array([med-arr[:,1],arr[:,2]-med]),fmt='o',capsize=4,color=colors[0],lw=1.5)
 ax.axhline(0,color='#777777',ls='--',lw=.8);ax.set_xticks([16,24]);ax.set_xlabel('In-plane spacing (nm)');ax.set_title(label,fontsize=9);ax.grid(axis='y',alpha=.15)
 for xx,yy in zip([16,24],med):ax.annotate(f'{yy:+.2f}%',(xx,yy),xytext=(5,0),textcoords='offset points',fontsize=7)
 ax.set_xlim(12,31)
axs[0].set_ylabel('Change from native mesh (%)');save(fig,'resolution_sensitivity')
